﻿using System;
using System.Collections.Generic;
using System.Text;

namespace mobilna
{
    internal static class Users
    {
        internal static List<User> users = new List<User>();
    }
}
